import auto_tester

if __name__ == '__main__':
    auto_tester.main()